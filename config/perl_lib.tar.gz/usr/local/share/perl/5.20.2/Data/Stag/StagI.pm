package Data::Stag::StagI;

sub z {
}

1;
